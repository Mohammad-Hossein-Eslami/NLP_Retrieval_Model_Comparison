import pandas as pd
import random
import csv

# === Configuration ===
input_file = 'retrieval_results.csv'
shuffled_output_file = 'shuffled_data.csv'
shuffle_mapping_file = 'column_shuffle_mapping.csv'

# === Step 1: Read CSV ===
df = pd.read_csv(input_file)

# === Step 2: Separate first column (keep as-is) and columns 2 to 10 (to shuffle) ===
first_column = df.iloc[:, [0]]  # Keep column 1
other_columns = df.iloc[:, 1:]  # Columns 2 to 10

# === Step 3: Shuffle columns 2 to 10 ===
original_colnames = other_columns.columns.tolist()
shuffled_colnames = original_colnames.copy()
random.shuffle(shuffled_colnames)

# === Step 4: Save the shuffle mapping ===
with open(shuffle_mapping_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Original Column', 'Shuffled Position'])
    for idx, col in enumerate(shuffled_colnames):
        writer.writerow([col, f'output{idx + 1}'])

# === Step 5: Combine first column and shuffled others ===
df_shuffled = pd.concat([first_column, other_columns[shuffled_colnames]], axis=1)

# === Step 6: Rename columns as requested ===
new_columns = ['questions'] + [f'output{i}' for i in range(1, 10)]
df_shuffled.columns = new_columns

# === Step 7: Save shuffled data with new headers ===
df_shuffled.to_csv(shuffled_output_file, index=False)
