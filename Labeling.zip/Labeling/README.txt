-label_extractor.py: the code to extract the rankings from label studio's output

-prepare_labeling.py: the code to prepare the output of the models before labeling 

-metric.ipynb: notebook regarding the calculation of different metrics used in evaluation

NLP_HW2_Label_*.json: The output of label_studio labeling

labels_output_*.csv: The final ranking for each of the questions