import json
import csv

# Load your JSON file
with open("NLP_HW2_Label.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Open a CSV file for writing
with open("labels_output.csv", "w", newline='', encoding="utf-8-sig") as csvfile:
    writer = csv.writer(csvfile)
    
    # Write header
    writer.writerow(["entry_id", "rating1", "rating2", "rating3", "rating4", "rating5", "rating6", "rating7", "rating8", "rating9"])
    
    # Process each entry
    for entry in data:
        entry_id = entry["id"]
        annotation = entry["annotations"][0]  # Assuming there's always one annotation per entry
        results = annotation["result"]

        # Extract the numbers (as strings) from the result fields
        ratings = [r["value"]["text"][0] for r in results]  # ["9", "7", ..., "1"]

        # Write to CSV
        writer.writerow([entry_id] + ratings)
