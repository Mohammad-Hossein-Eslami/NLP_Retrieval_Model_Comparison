- duplicates: This file contains all the duplicate pairs 

- result: The final output of the three models, each the 3 top answers, with the questions included