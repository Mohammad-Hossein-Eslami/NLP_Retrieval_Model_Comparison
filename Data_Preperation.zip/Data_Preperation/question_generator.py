# batch_foods_gemma_prompt_with_json.py
import os
import json
from pathlib import Path
import google.generativeai as genai
from google.api_core.exceptions import GoogleAPIError

# --- Configuration ---
INPUT_JSON = Path("/kaggle/input/passages/passages17.json")
OUTPUT_JSON = Path("/kaggle/working/questions17.json")
BATCH_SIZE = 50

# Prefix to prepend to the full food entry JSON
PROMPT_PREFIX = (
    "take a look at this passage. I want find at least 5 questions in persian using the information given in the passage. Please make sure that the questions are in Persian only and their answer can be found in the given passage. Remeber, the questions should only be in Persian. Remember that I want AT LEAST 5 questions. You do not have to put in the answers. Also, No English should be included in the output. Also no introduction is needed. Just start with the questions straight"
)

API_KEY = "Hello There!!"
if not API_KEY:
    raise RuntimeError("Set the GEMINI_API_KEY environment variable.")

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemma-3-27b-it")
GEN_CONFIG = {"max_output_tokens": 120, "temperature": 0.7}

# --- Load data ---
with INPUT_JSON.open("r", encoding="utf-8") as f:
    passages = json.load(f)

if not isinstance(passages, list):
    raise ValueError("foods.json must contain a list of food entries.")

# --- Process entries in batches ---
results = []
total = len(passages)

batch = passages[0:100]
for idx, food in enumerate(batch):
    title = food.get("title", f"Untitled {idx}")
    entry_text = json.dumps(food, ensure_ascii=False)
    full_prompt = PROMPT_PREFIX + entry_text

    print(f"  → [{idx}] {title}")
    try:
        response = model.generate_content(full_prompt, generation_config=GEN_CONFIG)
        text = response.text
    except GoogleAPIError as e:
        print(f"  [ERROR] Failed for {title}: {e.message}")
        text = None

    results.append({
        "title": title,
        "response": text,
    })


    

# --- Save responses ---
with OUTPUT_JSON.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print(f"✅ Done! Saved {len(results)} responses to {OUTPUT_JSON}")
