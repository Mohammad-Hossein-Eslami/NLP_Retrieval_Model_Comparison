import json

N = 11
with open(f"{N}.json", "r", encoding="utf-8") as f:
    dataset = json.load(f)

clean_data = []

for data in dataset:
    title = data.get('title', '')
    
    # build location properly
    locations_list = data.get('locations', [])
    if locations_list:
        loc = locations_list[0]
        location = {
            "province": loc.get("province", ""),
            "city": loc.get("city", ""),
            "coordinates": {
                "latitude": loc.get("latitude", 0.0),
                "longitude": loc.get("longitude", 0.0)
            }
        }
    else:
        location = {
            "province": "",
            "city": "",
            "coordinates": {
                "latitude": 0.0,
                "longitude": 0.0
            }
        }

    ingredients = data.get('ingredients', [])
    instructions = data.get('instructions', [])
    meal_type = data.get('meal_type', [])
    occasion = data['occasion']
    occasion = [occasion]
    images = data.get('images', {})

    answer = data['answer']
    answer2 = data['answer2']

    if answer == "Good" and answer2 == "Good":
        clean_data.append({
            "title": title,
            "location": location,
            "ingredients": ingredients,
            "instructions": instructions,
            "meal_type": meal_type,
            "occasion": occasion
        })

with open(f"{N}_clean.json", "w", encoding="utf-8") as json_file:
    json.dump(clean_data, json_file, ensure_ascii=False, indent=2)
