import json

# replace this with your input file name
input_file = "1.json"
output_file = "1_clean.json"

def safe_load(s, field_name=""):
    try:
        return json.loads(s)
    except Exception as e:
        print(f"[WARN] Failed to parse field '{field_name}': {e}")
        return s

def clean_occasion(occasion_field):
    """
    Takes occasion field (list or string), and splits any strings containing '/' into a list of parts.
    """
    if isinstance(occasion_field, list):
        result = []
        for item in occasion_field:
            if isinstance(item, str) and "/" in item:
                # split on '/' and strip spaces
                result.extend([part.strip() for part in item.split("/")])
            else:
                result.append(item)
        return result
    elif isinstance(occasion_field, str):
        if "/" in occasion_field:
            return [part.strip() for part in occasion_field.split("/")]
        else:
            return [occasion_field]
    else:
        return occasion_field  # fallback

with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)

clean_data = []

for idx, record in enumerate(data):
    raw_occasion = safe_load(record.get("occasion", ""), "occasion")
    cleaned_record = {
        "title": record.get("title", ""),
        "location": safe_load(record.get("location", ""), "location"),
        "ingredients": safe_load(record.get("ingredients", ""), "ingredients"),
        "instructions": safe_load(record.get("instructions", ""), "instructions"),
        "meal_type": safe_load(record.get("meal_type", ""), "meal_type"),
        "occasion": clean_occasion(raw_occasion)
    }

    clean_data.append(cleaned_record)

with open(output_file, "w", encoding="utf-8") as out:
    json.dump(clean_data, out, ensure_ascii=False, indent=2)

print(f"✅ Done! Cleaned data saved to: {output_file}")
