import json

N = 8
with open(f"{N}.json", "r", encoding="utf-8") as f:
    dataset = json.load(f)

clean_data = []

for data in dataset :

    title = data['title']
    location = data['location']
    
    instructions = data['instructions']
    meal_type = data['meal_type']
    meal_type = [meal_type]
    occasion = []                           # file 6 does not have this field ! so we will set it empty!
    ingredients = data['ingredients']        # ingredients only has name and amount so we will add unit 
                                            # the ingredients is not clean at all ! 

for ingredient in ingredients: 
    ingredient['unit'] = ""             
    

    clean_data.append({
        "title": title,
        "location": location,
        "ingredients": ingredients,
        "instructions": instructions,
        "meal_type": meal_type,
        "occasion": occasion
    })

    #NO occasion and meal type!



with open(f"{N}_clean.json", "w", encoding="utf-8") as json_file:
    json.dump(clean_data, json_file, ensure_ascii=False, indent=2)