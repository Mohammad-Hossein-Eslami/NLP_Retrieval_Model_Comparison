import json
import os

output_file = "merged.json"
merged_data = []

for i in range(1, 18): 
    filename = f"{i}_clean.json"

    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list):
            merged_data.extend(data)
        else:
            merged_data.append(data)

with open(output_file, "w", encoding="utf-8") as out:
    json.dump(merged_data, out, ensure_ascii=False, indent=2)
