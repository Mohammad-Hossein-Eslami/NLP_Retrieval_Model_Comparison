import json

N = 15
with open(f"{N}.json", "r", encoding="utf-8") as f:
    dataset = json.load(f)

clean_data = []

for data in dataset :

    title = data['title']
    location = data['location']
    ingredients = data['ingredients']
    instructions = data['instructions']
    meal_type = data['meal_type']
    occasion = data['occasion']
    occasion = [occasion]
    images = data['images']

    clean_data.append({
        "title": title,
        "location": location,
        "ingredients": ingredients,
        "instructions": instructions,
        "meal_type": meal_type,
        "occasion": occasion
    })



with open(f"{N}_clean.json", "w", encoding="utf-8") as json_file:
    json.dump(clean_data, json_file, ensure_ascii=False, indent=2)