import json
import re

N = 7

with open(f"{N}.json", "r", encoding="utf-8") as f:
    dataset = json.load(f)

clean_data = []

# helper to parse amount and unit
def parse_amount(amount_str):
    if not amount_str:
        return "", ""
    # simple regex: split at first space
    parts = amount_str.strip().split(" ", 1)
    if len(parts) == 2:
        amount, unit = parts
    else:
        amount, unit = parts[0], ""
    return amount, unit

for data in dataset:
    if data.get('quality_label') != "Good":
        continue

    title = data.get('title', '')
    location = data.get('location', '')
    ingredients_raw = data.get('ingredients', [])
    instructions = data.get('instructions', '')
    meal_type = data.get('meal_type', '')
    occasion = data.get('occasion', '')

    # fix occasion
    if isinstance(occasion, str):
        occasion = [part.strip() for part in occasion.split("/")]

    # fix ingredients
    ingredients = []
    for ing in ingredients_raw:
        name = ing.get("name", "")
        amount_raw = ing.get("amount", "")
        amount, unit = parse_amount(amount_raw)
        ingredients.append({
            "name": name,
            "amount": amount,
            "unit": unit
        })

    clean_data.append({
        "title": title,
        "location": location,
        "ingredients": ingredients,
        "instructions": instructions,
        "meal_type": meal_type,
        "occasion": occasion
    })

with open(f"{N}_clean.json", "w", encoding="utf-8") as json_file:
    json.dump(clean_data, json_file, ensure_ascii=False, indent=2)

print(f"✅ Done! Saved {len(clean_data)} cleaned records to {N}_clean.json")
