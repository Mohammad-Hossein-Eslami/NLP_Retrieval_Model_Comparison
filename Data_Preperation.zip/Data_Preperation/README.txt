-Merger: The files for merging all the given raw data files into one single file

-passages.json: All the generated passages for each data entry in a single list

-merged.json: All the structured raw food data

-training_data.json: a list of dictionaries each having two keys. The first key is a created question (for training) and the second key is the corresponding passage

-questions.json: All the 50 evaluation questions 

-data_formatter.py: prepares the all_passages and questions_passage_pairs files

-passage_generator.py: Using API calls, creates passages from raw data

-question_generator.py: Using API calls, creates questions from each passage
 