import json
import os

# Folder containing the JSON files
folder_path = './'  # Change this if the files are in a different folder

all_passages = []
question_passage_pairs = []

# Loop over file indices 1 to 17
for i in range(1, 18):
    # Load passages and questions
    with open(os.path.join(folder_path, f'passages{i}.json'), encoding='utf-8') as pf:
        passages = json.load(pf)
    with open(os.path.join(folder_path, f'questions{i}.json'), encoding='utf-8') as qf:
        questions = json.load(qf)

    # Collect all passage responses
    for entry in passages:
        all_passages.append(entry['response'])

    # Build question-passage dictionaries
    for passage_entry, question_entry in zip(passages, questions):
        passage_text = passage_entry['response']
        questions_string = question_entry['response']
        questions_list = [q.strip() for q in questions_string.strip().split('\n') if q.strip()]

        # Drop the last question
        questions_list = questions_list[:-1]

        for question_text in questions_list:
            question_passage_pairs.append({
                'question': question_text,
                'passage': passage_text
            })

# Save results (optional)
with open('all_passages.json', 'w', encoding='utf-8-sig') as f:
    json.dump(all_passages, f, ensure_ascii=False, indent=2)

with open('question_passage_pairs.json', 'w', encoding='utf-8-sig') as f:
    json.dump(question_passage_pairs, f, ensure_ascii=False, indent=2)
