# batch_foods_gemma_prompt_with_json.py
import os
import json
from pathlib import Path
import google.generativeai as genai
from google.api_core.exceptions import GoogleAPIError

# --- Configuration ---
INPUT_JSON = Path("/kaggle/input/merged-foods/merged.json")
OUTPUT_JSON = Path("/kaggle/working/passages17.json")
BATCH_SIZE = 50

# Prefix to prepend to the full food entry JSON
PROMPT_PREFIX = (
    """take a look at this data structure. 
    I want you to write a paragraph in persian using the information given below. 
    Please make sure the paragraph is smooth and like a normal paragraph. 
    Use the information in each field. 
    Make sure that you include all the ingredients and instructions. 
    Do not miss them out. You can ingnore the image links as they are not important. 
    There shound not be any english in the response."""
)

API_KEY = "Hello There!!"
if not API_KEY:
    raise RuntimeError("Set the GEMINI_API_KEY environment variable.")

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemma-3-27b-it")
GEN_CONFIG = {"max_output_tokens": 500, "temperature": 0.7}

# --- Load data ---
with INPUT_JSON.open("r", encoding="utf-8") as f:
    foods = json.load(f)

if not isinstance(foods, list):
    raise ValueError("foods.json must contain a list of food entries.")

# --- Process entries in batches ---
results = []
total = len(foods)

batch = foods[1600:]
for idx, food in enumerate(batch):
    title = food.get("title", f"Untitled {idx}")
    entry_text = json.dumps(food, ensure_ascii=False)
    full_prompt = PROMPT_PREFIX + entry_text

    print(f"  → [{idx}] {title}")
    try:
        response = model.generate_content(full_prompt, generation_config=GEN_CONFIG)
        text = response.text
    except GoogleAPIError as e:
        print(f"  [ERROR] Failed for {title}: {e.message}")
        text = None

    results.append({
        "title": title,
        "response": text,
    })


    

# --- Save responses ---
with OUTPUT_JSON.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print(f"✅ Done! Saved {len(results)} responses to {OUTPUT_JSON}")
